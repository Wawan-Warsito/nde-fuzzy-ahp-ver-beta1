# NDE Fuzzy AHP Ver.Beta1

A Pen created on CodePen.

Original URL: [https://codepen.io/Wawan-Warsito/pen/zxvobRP](https://codepen.io/Wawan-Warsito/pen/zxvobRP).

